public class Mainclass
{
	public static void main(String[] args)
	{
		DnsApp app = new DnsApp(args[0]);
		app.run();
	}
}