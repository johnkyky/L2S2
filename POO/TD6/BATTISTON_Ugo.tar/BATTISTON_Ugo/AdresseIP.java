public class AdresseIP
{
	private String ip;
	
	public AdresseIP(String ip)
	{
		this.ip = new String(ip);
	}

	public String toString()
	{
		return ip;
	}
}