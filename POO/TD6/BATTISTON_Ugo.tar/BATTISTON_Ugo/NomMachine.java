public class NomMachine
{
	private String name;
	
	public NomMachine(String name)
	{
		this.name = new String(name);
	}

	public String toString()
	{
		return name;
	}
}