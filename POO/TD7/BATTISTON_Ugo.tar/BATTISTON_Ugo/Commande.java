interface Commande
{
	public void execute(String argv);
}