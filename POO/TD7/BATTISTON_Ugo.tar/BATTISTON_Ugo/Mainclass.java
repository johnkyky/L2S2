public class Mainclass
{
	public static void main(String[] args)
	{
		DrawableApp draw = new DrawableApp();
		draw.run();
	}
}