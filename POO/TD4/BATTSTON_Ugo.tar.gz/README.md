IN404 exercice 5.3.2

Exemple de l'implémentation de la librarie Apache (non présente dans l'archive) dans un projet java.
La compilation se fait grâce à la commande "make" dans le terminal. La commande "make clear" permet de supprimer les fichiers génénés par la compilation.
La librairie est supposée se trouver dans un dossier "jars" et est nonmée "commons-math3-3.6.1"

.
├── jars
│   └── commons-math3-3.6.1.jar
├── Mainclass.java
├── makefile
└── README.md