L'archive BATTISTON_Ugo.tar contient les fichiers :
- Le fichier README.md que vous êtes en train de lire.
- Mainclass.java CalculatriceRPN.java MoteurRPN.java SaisieRPN.java Operation.java
	fichiers sources du programme.
- Le fichier makefile permetant la compilation grâce à la commande make. La supression des fichiers n'essessaire à 
	l'éxécution du programme se fait grâce à la commande make clear.
