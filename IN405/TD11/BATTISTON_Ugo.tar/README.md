L'archive BATTISTON_Ugo.tar contient les fichiers suivants :
- le fichier README.md, que vous êtes en train de lire ;
- le fichier main.c, fonction.c, fonctionThread.c, listPage.c, fichiers sources du programme;
- le fichier fonction.h, fonctionThread.h, listPage.h, fichiers d'en-tête du programme;


La compilation du projet se fait à l'aide de la commande suivante :
$ make
La supression des fichiers nessessaires à la compilation se fait à l'aide de la commande suivante :
$ make clear

Le fichier config est le fichier contenant la configuration du programme.