# Description
L'archive BATTISTON_Ugo.tar contient les fichiers suivants :
- le fichier README.md, que vous êtes en train de lire
- le dossier src qui contient les fichiers sources du programme : client.c , server.c, million.c
- le dossier obj qui contient les fichiers temporaires dû à la compilation

# Utilisation
La compilation se fait grâce à la commande make, la supression des fichiers créé apres la compilation avec la commande make clear.